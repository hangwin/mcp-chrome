const NATIVE_HOST = {
  NAME: "com.agentchromemcp.nativehost",
  LEGACY_DEFAULT_PORT: 12306,
  DEFAULT_PORT: 12307
};
const LINKS = {
  TROUBLESHOOTING: "https://github.com/hangwin/mcp-chrome/blob/master/docs/TROUBLESHOOTING.md"
};
const STORAGE_KEYS = {
  USERSCRIPTS_DISABLED: "userscripts_disabled"
};
export {
  LINKS as L,
  NATIVE_HOST as N,
  STORAGE_KEYS as S
};
